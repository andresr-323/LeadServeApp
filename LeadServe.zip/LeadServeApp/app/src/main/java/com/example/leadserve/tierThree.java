package com.example.leadserve;

public class tierThree extends tier {
    private int LeadershipLegProj;
    private int LEAD3000;
    private int leadershipPort;
    private int showcase;

    tierThree(){
        super();
    }

    public int getLeadershipLegProj() {
        return LeadershipLegProj;
    }

    public void setLeadershipLegProj(int leadershipLegProj) {
        LeadershipLegProj = leadershipLegProj;
    }

    public int getLEAD3000() {
        return LEAD3000;
    }

    public void setLEAD3000(int LEAD3000) {
        this.LEAD3000 = LEAD3000;
    }

    public int getLeadershipPort() {
        return leadershipPort;
    }

    public void setLeadershipPort(int leadershipPort) {
        this.leadershipPort = leadershipPort;
    }

    public int getShowcase() {
        return showcase;
    }

    public void setShowcase(int showcase) {
        this.showcase = showcase;
    }
}
