package com.example.leadserve;

public class tierTwo extends tier  {
    private int fivehour;
    private int legacyProjectProp;
    private int LEAD2000;
    private int showcase;

    tierTwo(){
        super();

    }

    public int getFivehour() {
        return fivehour;
    }

    public void setFivehour(int fivehour) {
        this.fivehour = fivehour;
    }

    public int getLegacyProjectProp() {
        return legacyProjectProp;
    }

    public void setLegacyProjectProp(int legacyProjectProp) {
        this.legacyProjectProp = legacyProjectProp;
    }

    public int getLEAD2000() {
        return LEAD2000;
    }

    public void setLEAD2000(int LEAD2000) {
        this.LEAD2000 = LEAD2000;
    }

    public int getShowcase() {
        return showcase;
    }

    public void setShowcase(int showcase) {
        this.showcase = showcase;
    }
}
